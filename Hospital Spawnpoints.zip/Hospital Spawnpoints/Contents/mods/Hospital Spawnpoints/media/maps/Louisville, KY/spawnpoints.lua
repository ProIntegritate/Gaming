-- How to calculate SP coordinates from ingame coordinates:
-- Game (teleport) coordinates 12392,3624,1
-- Becomes
-- x = 12392 -> worldX = 41(*300) + posx = 92
-- y = 3624 -> worldY = 12(*300) + posy = 24
-- z = 1 -> 1. Duh.

function SpawnPoints()
return {
  unemployed = {
    { worldX = 41, worldY = 12, posX = 116, posY = 85, posZ = 2 },
    { worldX = 41, worldY = 12, posX = 117, posY = 121, posZ = 2 },
    { worldX = 41, worldY = 12, posX = 129, posY = 74, posZ = 1 },
    { worldX = 41, worldY = 12, posX = 75, posY = 77, posZ = 0 },
    { worldX = 41, worldY = 12, posX = 66, posY = 84, posZ = 0 },
    { worldX = 41, worldY = 12, posX = 79, posY = 84, posZ = 1 },
    { worldX = 41, worldY = 12, posX = 92, posY = 25, posZ = 1 },
  }
}
end
