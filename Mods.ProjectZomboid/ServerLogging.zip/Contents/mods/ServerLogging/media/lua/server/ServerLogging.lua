-- Exit if not server. Client should not run this. Ever.
if not isServer() or isClient() then return end

local function fLogPlayerData()

	-- Get system time. We do NOT want ingame time, but the actual IRL time so we can correlated between players and ingame events.
	local sTimestamp = os.date("%Y-%m-%dT%H:%M:%SZ"); --ISO 8601, Zulu time (UTC)

	if not sPrevTimestamp then -- Global to survive outside this function. Makes this only write once per second when players are sleeping.
		sPrevTimestamp = sTimestamp;
	end

	-- Run this max ONCE per real life second.
	-- Sleeping triggers this a crapload of times as ingame time is accellerated.
	if sTimestamp ~= sPrevTimestamp then 
		
		-- Define file to append to and write it.
		local sFilename = "users.log"; -- Writes file to %USERPROFILE%\Zomboid\Lua\users.log
		local writer = getFileWriter(sFilename, true, true); -- Using APPEND mode.

		-- Get active players into array of Player objects
		local players = getOnlinePlayers();

		for i=0, players:size()-1 do
		
			local p = players:get(i);
			
			--Character name + Useraccount.
			local sFirstname = p:getDescriptor():getForename();
			local sLastname = p:getDescriptor():getSurname();
			local sUsername = p:getUsername();
			local sUserMeta = "NAME: " .. sFirstname .. " " .. sLastname .. " (" .. sUsername .. ")";
			
			-- Position of player characters in the world.
			local playerX = math.floor(p:getX());
			local playerY = math.floor(p:getY());
			local playerZ = math.floor(p:getZ());
			local sPosition = "POSITION: x=" .. playerX .. " Y=" .. playerY .. " Z=" .. playerZ;

			-- Movement. Lots doesn't seem to be working properly: movementspeed = always the same, isrunning = never changes etc.
			local bisSeatedInVehicle = 0;
			if p:isSeatedInVehicle() == true then bisSeatedInVehicle = 1 end;
			local sMovement = "MOVEMENT: InVehicle=" .. bisSeatedInVehicle;

			-- Kill/Death stats
			local iSurvivorKills = p:getSurvivorKills();
			local iZombieKills = p:getZombieKills();
			local iDieCount = p:getDieCount();
			local iIsAlive = 1;
			if p:isAlive() == false then iIsAlive = 0 end;
			
			local sKillDeath = "DEATHSTATS: ";
			sKillDeath = sKillDeath .. "IsAlive=" .. iIsAlive .. " ";
			sKillDeath = sKillDeath .. "DieCount=" .. iDieCount .. " ";
			sKillDeath = sKillDeath .. "SurvivorKills=" .. iSurvivorKills .. " ";
			sKillDeath = sKillDeath .. "ZombieKills=" .. iZombieKills;

			-- Active Cheats
			local bisGodMode = 0;
			local bIsBuildCheat = 0;
			local bisInvincible = 0;
			local bisInvisible = 0;
			local bisMechanicsCheat = 0;
			local bisMovablesCheat = 0;
			local bisUnlimitedCarry = 0;
			local bisUnlimitedEndurance = 0;

			if p:isGodMod() == true then bisGodMode = 1 end;
			if p:isInvincible() == true then bisInvincible = 1 end;
			if p:isInvisible() == true then bisInvisible = 1 end;
			if p:isBuildCheat() == true then bIsBuildCheat = 1 end;
			if p:isMechanicsCheat() == true then bisMechanicsCheat = 1 end;
			if p:isMovablesCheat() == true then bisMovablesCheat = 1 end;
			if p:isUnlimitedCarry() == true then bisUnlimitedCarry = 1 end;
			if p:isUnlimitedEndurance() == true then bisUnlimitedEndurance = 1 end;

			local sCheatStats = "CHEATS: ";
			sCheatStats = sCheatStats .. "GodMode=" .. bisGodMode .. " ";
			sCheatStats = sCheatStats .. "Invincible=" .. bisInvincible .. " ";
			sCheatStats = sCheatStats .. "Invisible=" .. bisInvisible .. " ";
			sCheatStats = sCheatStats .. "BuildCheat=" .. bIsBuildCheat .. " ";
			sCheatStats = sCheatStats .. "MechanicsCheat=" .. bisMechanicsCheat .. " ";
			sCheatStats = sCheatStats .. "MovablesCheat=" .. bisMovablesCheat .. " ";
			sCheatStats = sCheatStats .. "UnlimitedCarry=" .. bisUnlimitedCarry .. " ";
			sCheatStats = sCheatStats .. "UnlimitedEndurance=" .. bisUnlimitedEndurance;

			-- TODO: Apparently, getting SteamID SERVERSIDE as a STRING (not a long, that cant be printed/logged) is impossible.
			-- And the LONG values ARE NOT CORRECT, mine from ISOPLAYER object was off by 4(!) and resolved to someone else.
			--local sSteamID = "SteamID: " .. tostring(p:getSteamID());
			--local sSteamID = "SteamID: " .. getSteamIDFromUsername(sUsername));
			--local sSteamID = "SteamID: " .. tostring(lSteamID);
			--local lSteamID = getCurrentUserSteamID(sUsername);
			--local sSteamID = "SteamID: " .. lSteamID;

			writer:write(sTimestamp);	-- Timestamp and character+username will ALWAYS be logged.
			writer:write(", ");
			writer:write(sUserMeta);
			
			
			if SandboxVars.ServerLogging.Positions == true then
				writer:write(", ");
				writer:write(sPosition);
			end

			if SandboxVars.ServerLogging.Movement == true then
				writer:write(", ");
				writer:write(sMovement);
			end
			
			if SandboxVars.ServerLogging.Deathstats == true then
				writer:write(", ");
				writer:write(sKillDeath);
			end
			
			if SandboxVars.ServerLogging.Cheats == true then
				writer:write(", ");
				writer:write(sCheatStats);
			end

			writer:write("\n");

		end

		writer:close();
		
		sPrevTimestamp = sTimestamp;

	end
	
end

-- Chose which callback to use to set logging frequency.
-- Every minute, 10 minutes or an hour.
-- These are ingame time units and data will be written depending on the time setting of your server.
-- Default = every 10 minutes, as seen below

--Events.EveryHours.Add(fLogPlayerData);
Events.EveryTenMinutes.Add(fLogPlayerData);

