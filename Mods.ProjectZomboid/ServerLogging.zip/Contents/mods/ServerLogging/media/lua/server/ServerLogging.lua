-- Exit if not server. Client should not run this. Ever.
if not isServer() or isClient() then return end

local function fLogPlayerData()

	-- Get system time. We do NOT want ingame time, but the actual IRL time so we can correlated between players and ingame events.
	local sTimestamp = os.date("%Y-%m-%dT%H:%M:%SZ"); --ISO 8601, Zulu time (UTC)

	if not sPrevTimestamp then -- Global to survive outside this function. Makes this only write once per second when players are sleeping.
		sPrevTimestamp = sTimestamp;
	end
	
	if sTimestamp ~= sPrevTimestamp then -- Run max ONCE per real life second. Sleeping triggers this a crapload of times as ingame time is accellerated.
		
		-- Get active players into array of Player objects
		local players = getOnlinePlayers();

		for i=0, players:size()-1 do
		
			local p = players:get(i);
			
			--Character name + Useraccount.
			local sFirstname = p:getDescriptor():getForename();
			local sLastname = p:getDescriptor():getSurname();
			local sUsername = p:getUsername();
			local sUserMeta = "NAME: " .. sFirstname .. " " .. sLastname .. " (" .. sUsername .. ")";
			
			-- Position of player characters in the world.
			local playerX = math.floor(p:getX());
			local playerY = math.floor(p:getY());
			local playerZ = math.floor(p:getZ());
			local sPosition = "POSITION: x=" .. playerX .. " Y=" .. playerY .. " Z=" .. playerZ;

			-- Define file to append to and write it.
			local sFilename = "users.log"; -- Writes file to %USERPROFILE%\Zomboid\Lua\users.log
			local writer = getFileWriter(sFilename, true, true); -- Using APPEND mode.
			
			-- TODO: Apparently, getting SteamID SERVERSIDE as string is impossible. And LONG values are NOT correct, mine from ISOPLAYER object was off by 4(!)
			--local sSteamID = "SteamID: " .. tostring(p:getSteamID());
			--local sSteamID = "SteamID: " .. getSteamIDFromUsername(sUsername));
			--local sSteamID = "SteamID: " .. tostring(lSteamID);
			--local lSteamID = getCurrentUserSteamID(sUsername);
			--local sSteamID = "SteamID: " .. lSteamID;

			writer:write(sTimestamp);
			writer:write(", ");
			writer:write(sUserMeta);
			writer:write(", ");
			writer:write(sPosition);
			--writer:write(", ");
			--writer:write(sSteamID);
			writer:write("\n");
			writer:close();

		end

		sPrevTimestamp = sTimestamp;

	end
	
end

-- Chose which callback to use to set logging frequency.
-- Every minute, 10 minutes or an hour.
-- These are ingame time units and data will be written depending on the time setting of your server.
-- Default = every 10 minutes, as seen below

--Events.EveryHours.Add(fLogPlayerData);
Events.EveryTenMinutes.Add(fLogPlayerData);
--Events.EveryOneMinute.Add(fLogPlayerData);
