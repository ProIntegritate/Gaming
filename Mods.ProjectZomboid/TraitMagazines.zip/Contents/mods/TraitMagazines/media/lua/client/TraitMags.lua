require "TimedActions/ISReadABook"

local originalISReadABookPerform = ISReadABook.perform

function ISReadABook:perform(...)

-- /additem Base.TraitMagSpeedDemon

	if self.item:getFullType() == "Base.TraitMagSpeedDemon" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("SpeedDemon") then
				traits:add("SpeedDemon")
			else
				traits:remove("SpeedDemon")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagDextrous" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Dextrous") then
				traits:add("Dextrous")
			else
				traits:remove("Dextrous")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagFastReader" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("FastReader") then
				traits:add("FastReader")
			else
				traits:remove("FastReader")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagOutdoorsman" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Outdoorsman") then
				traits:add("Outdoorsman")
			else
				traits:remove("Outdoorsman")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagIronGut" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("IronGut") then
				traits:add("IronGut")
			else
				traits:remove("IronGut")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagBrave" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Brave") then
				traits:add("Brave")
			else
				traits:remove("Brave")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagGraceful" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Graceful") then
				traits:add("Graceful")
			else
				traits:remove("Graceful")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagInconspicuous" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Inconspicuous") then
				traits:add("Inconspicuous")
			else
				traits:remove("Inconspicuous")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagLightEater" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("LightEater") then
				traits:add("LightEater")
			else
				traits:remove("LightEater")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagNutritionist" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Nutritionist") then
				traits:add("Nutritionist")
			else
				traits:remove("Nutritionist")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagOrganized" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Organized") then
				traits:add("Organized")
			else
				traits:remove("Organized")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	-- HERE

	if self.item:getFullType() == "Base.TraitMagLowThirst" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("LowThirst") then
				traits:add("LowThirst")
			else
				traits:remove("LowThirst")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagDesensitized" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Desensitized") then
				traits:add("Desensitized")
			else
				traits:remove("Desensitized")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagResilient" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Resilient") then
				traits:add("Resilient")
			else
				traits:remove("Resilient")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagAdrenalineJunkie" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("AdrenalineJunkie") then
				traits:add("AdrenalineJunkie")
			else
				traits:remove("AdrenalineJunkie")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagAthletic" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Athletic") then
				traits:add("Athletic")
			else
				traits:remove("Athletic")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagCatsEyes" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			-- TODO: CatsEyes does not work
			if not traits:contains("NightVision") then
				traits:add("NightVision")
			else
				traits:remove("NightVision")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagEagleEyed" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("EagleEyed") then
				traits:add("EagleEyed")
			else
				traits:remove("EagleEyed")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagFastHealer" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("FastHealer") then
				traits:add("FastHealer")
			else
				traits:remove("FastHealer")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagFastLearner" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("FastLearner") then
				traits:add("FastLearner")
			else
				traits:remove("FastLearner")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagKeenHearing" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("KeenHearing") then
				traits:add("KeenHearing")
			else
				traits:remove("KeenHearing")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagThickSkinned" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("ThickSkinned") then
				traits:add("ThickSkinned")
			else
				traits:remove("ThickSkinned")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagWakeful" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			-- TODO: Wakefull does not work
			if not traits:contains("NeedsLessSleep") then
				traits:add("NeedsLessSleep")
			else
				traits:remove("NeedsLessSleep")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	if self.item:getFullType() == "Base.TraitMagNightOwl" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("NightOwl") then
				traits:add("NightOwl")
			else
				traits:remove("NightOwl")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end
	
	return originalISReadABookPerform(self, ...)

end
