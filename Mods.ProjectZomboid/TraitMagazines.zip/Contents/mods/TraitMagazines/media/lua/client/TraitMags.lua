require "TimedActions/ISReadABook"

local originalISReadABookPerform = ISReadABook.perform

function ISReadABook:perform(...)

--TraitMagFastReader2

	if self.item:getFullType() == "Base.TraitMagSpeedDemon" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("SpeedDemon") then
				traits:add("SpeedDemon")
			else
				traits:remove("SpeedDemon")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagDextrous" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Dextrous") then
				traits:add("Dextrous")
			else
				traits:remove("Dextrous")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagFastReader" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("FastReader") then
				traits:add("FastReader")
			else
				traits:remove("FastReader")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagOutdoorsman" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Outdoorsman") then
				traits:add("Outdoorsman")
			else
				traits:remove("Outdoorsman")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagIronGut" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("IronGut") then
				traits:add("IronGut")
			else
				traits:remove("IronGut")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagBrave" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Brave") then
				traits:add("Brave")
			else
				traits:remove("Brave")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagGraceful" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Graceful") then
				traits:add("Graceful")
			else
				traits:remove("Graceful")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagInconspicuous" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Inconspicuous") then
				traits:add("Inconspicuous")
			else
				traits:remove("Inconspicuous")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagLightEater" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("LightEater") then
				traits:add("LightEater")
			else
				traits:remove("LightEater")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagNutritionist" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Nutritionist") then
				traits:add("Nutritionist")
			else
				traits:remove("Nutritionist")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagOrganized" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Organized") then
				traits:add("Organized")
			else
				traits:remove("Organized")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	return originalISReadABookPerform(self, ...)

end
