require "TimedActions/ISReadABook"

local originalISReadABookPerform = ISReadABook.perform

function ISReadABook:perform(...)

--TraitMagFastReader2

	if self.item:getFullType() == "Base.TraitMagSpeedDemon" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("SpeedDemon") then
				traits:add("SpeedDemon")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagDextrous" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Dextrous") then
				traits:add("Dextrous")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagFastReader" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("FastReader") then
				traits:add("FastReader")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagOutdoorsman" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Outdoorsman") then
				traits:add("Outdoorsman")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagIronGut" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("IronGut") then
				traits:add("IronGut")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagBrave" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Brave") then
				traits:add("Brave")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagGraceful" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Graceful") then
				traits:add("Graceful")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagInconspicuous" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Inconspicuous") then
				traits:add("Inconspicuous")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagLightEater" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("LightEater") then
				traits:add("LightEater")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagNutritionist" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Nutritionist") then
				traits:add("Nutritionist")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagOrganized" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Organized") then
				traits:add("Organized")
			end

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	return originalISReadABookPerform(self, ...)

end
