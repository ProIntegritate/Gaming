require "TimedActions/ISReadABook"

local originalISReadABookPerform = ISReadABook.perform

function ISReadABook:perform(...)

	if self.item:getFullType() == "Base.TraitMagAgoraphobic" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Agoraphobic") then
				traits:add("Agoraphobic")
			else
				traits:remove("Agoraphobic")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagAllThumbs" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("AllThumbs") then
				traits:add("AllThumbs")
			else
				traits:remove("AllThumbs")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagAsthmatic" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Asthmatic") then
				traits:add("Asthmatic")
			else
				traits:remove("Asthmatic")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagClaustophobic" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Claustophobic") then
				traits:add("Claustophobic")
			else
				traits:remove("Claustophobic")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagClumsy" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Clumsy") then
				traits:add("Clumsy")
			else
				traits:remove("Clumsy")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagConspicuous" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Conspicuous") then
				traits:add("Conspicuous")
			else
				traits:remove("Conspicuous")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagCowardly" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Cowardly") then
				traits:add("Cowardly")
			else
				traits:remove("Cowardly")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagDeaf" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Deaf") then
				traits:add("Deaf")
			else
				traits:remove("Deaf")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagDisorganized" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Disorganized") then
				traits:add("Disorganized")
			else
				traits:remove("Disorganized")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagEmaciated" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Emaciated") then
				traits:add("Emaciated")
			else
				traits:remove("Emaciated")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagFeeble" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Feeble") then
				traits:add("Feeble")
			else
				traits:remove("Feeble")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagHardOfHearing" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("HardOfHearing") then
				traits:add("HardOfHearing")
			else
				traits:remove("HardOfHearing")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagHeartyAppitite" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("HeartyAppitite") then
				traits:add("HeartyAppitite")
			else
				traits:remove("HeartyAppitite")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagHemophobic" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Hemophobic") then
				traits:add("Hemophobic")
			else
				traits:remove("Hemophobic")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagHighThirst" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("HighThirst") then
				traits:add("HighThirst")
			else
				traits:remove("HighThirst")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagIlliterate" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Illiterate") then
				traits:add("Illiterate")
			else
				traits:remove("Illiterate")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagInsomniac" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Insomniac") then
				traits:add("Insomniac")
			else
				traits:remove("Insomniac")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagNeedsMoreSleep" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("NeedsMoreSleep") then
				traits:add("NeedsMoreSleep")
			else
				traits:remove("NeedsMoreSleep")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagObese" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Obese") then
				traits:add("Obese")
			else
				traits:remove("Obese")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagOutofShape" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Out of Shape") then
				traits:add("Out of Shape")
			else
				traits:remove("Out of Shape")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagOverweight" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Overweight") then
				traits:add("Overweight")
			else
				traits:remove("Overweight")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagPacifist" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Pacifist") then
				traits:add("Pacifist")
			else
				traits:remove("Pacifist")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagProneToIllness" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("ProneToIllness") then
				traits:add("ProneToIllness")
			else
				traits:remove("ProneToIllness")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagShortSighted" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("ShortSighted") then
				traits:add("ShortSighted")
			else
				traits:remove("ShortSighted")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagSlowHealer" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("SlowHealer") then
				traits:add("SlowHealer")
			else
				traits:remove("SlowHealer")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagSlowLearner" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("SlowLearner") then
				traits:add("SlowLearner")
			else
				traits:remove("SlowLearner")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagSlowReader" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("SlowReader") then
				traits:add("SlowReader")
			else
				traits:remove("SlowReader")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagSmoker" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Smoker") then
				traits:add("Smoker")
			else
				traits:remove("Smoker")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagSundayDriver" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("SundayDriver") then
				traits:add("SundayDriver")
			else
				traits:remove("SundayDriver")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagThinskinned" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Thinskinned") then
				traits:add("Thinskinned")
			else
				traits:remove("Thinskinned")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagUnderweight" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Underweight") then
				traits:add("Underweight")
			else
				traits:remove("Underweight")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagVeryUnderweight" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Very Underweight") then
				traits:add("Very Underweight")
			else
				traits:remove("Very Underweight")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagUnfit" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Unfit") then
				traits:add("Unfit")
			else
				traits:remove("Unfit")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagWeak" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("Weak") then
				traits:add("Weak")
			else
				traits:remove("Weak")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	if self.item:getFullType() == "Base.TraitMagWeakStomach" then

		local characterMetaTable = getmetatable(self.character)
		local originalReadLiterature = characterMetaTable.__index.ReadLiterature

		characterMetaTable.__index.ReadLiterature = function(character, ...)

			local traits = character:getTraits()

			if not traits:contains("WeakStomach") then
				traits:add("WeakStomach")
			else
				traits:remove("WeakStomach")
			end
			

		end
		
		local result = originalISReadABookPerform(self, ...)

		characterMetaTable.__index.ReadLiterature = originalReadLiterature

		return result
		
	end

	
	return originalISReadABookPerform(self, ...)

end


