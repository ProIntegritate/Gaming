
Events.OnGameBoot.Add(
   function()
         SystemDisabler.setEnableAdvancedSoundOptions(true)
   end
)

