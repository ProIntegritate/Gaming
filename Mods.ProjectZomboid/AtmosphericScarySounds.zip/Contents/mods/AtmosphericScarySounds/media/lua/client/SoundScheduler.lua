local function fPlaysounds()

	if not laststate then
		laststate = 100; -- set to something OOB to make initial trigger
		--getPlayer():addLineChatElement("laststate set", 0.9 , 0.8 , 0.0);	
	end

	local hour = GameTime:getInstance():getHour();
	local daytime = 2;
	
	-- daytime Value
	-- 0 = Morning,			(06:00-10:00)
	-- 1 = Daytime,			(11:00-21:00)
	-- 2 = Night (default)	(22:00-06:00)
	
	-- Morning
	if hour >= 6 and hour <= 10 then
		daytime = 0;
	end

	-- Daytime
	if hour >= 11 and hour <= 21 then
		daytime = 1;
	end

	if daytime == 0 and laststate ~= 0 then
		if not getPlayer():isAsleep() then
			laststate = 0;
			--getPlayer():addLineChatElement("Playsound: Morning", 0.9 , 0.8 , 0.0);	
			getSoundManager():PlaySound("SoundMorning", false, 0);
		end
	end

	if daytime == 1 and laststate ~= 1 then
		if not getPlayer():isAsleep() then
			laststate = 1;
			--getPlayer():addLineChatElement("Playsound: Daytime", 0.9 , 0.8 , 0.0);	
			getSoundManager():PlaySound("SoundDaytime", false, 0);
		end
	end

	if daytime == 2 and laststate ~= 2 then
		if not getPlayer():isAsleep() then
			laststate = 2;
			--getPlayer():addLineChatElement("Playsound: Nighttime", 0.9 , 0.8 , 0.0);	
			getSoundManager():PlaySound("SoundNighttime", false, 0);
		end
	end

end

Events.EveryTenMinutes.Add(fPlaysounds);
